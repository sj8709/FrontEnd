package com.inhatc.domain;


import lombok.Data;

@Data
public class StudentInfoVO {

	private String stu_id;
	private String stu_name;
	private String address;
	private String phone;
	private String email;
}
