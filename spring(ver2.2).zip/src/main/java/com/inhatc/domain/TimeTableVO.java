package com.inhatc.domain;

import java.util.Date;

import lombok.Data;

@Data
public class TimeTableVO {

	private Long tno;
	private Long grade;
	private String tclass;
	private String professor;
	private String day_of_week;
	private String room;
	private Date regdate;
}
