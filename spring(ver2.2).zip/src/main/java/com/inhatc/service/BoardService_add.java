package com.inhatc.service;

import java.util.List;

import com.inhatc.domain.BoardVO;


public interface BoardService_add {

	public void register(BoardVO board);

	public BoardVO get(Long bno);

	public boolean modify(BoardVO board);

	public boolean remove(Long bno);

	public List<BoardVO> getList();



}
