package com.inhatc.service;

import java.util.List;

import com.inhatc.domain.TimeTableVO;


public interface TimeTableService {

	public void register(TimeTableVO timeTable);

	public TimeTableVO get(String professor);

	public boolean modify(TimeTableVO timeTable);

	public boolean remove(String professor);

	public List<TimeTableVO> getList();



}
