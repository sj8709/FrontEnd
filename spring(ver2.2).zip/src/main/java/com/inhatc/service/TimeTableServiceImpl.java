package com.inhatc.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.inhatc.domain.TimeTableVO;

import com.inhatc.mapper.TimeTableMapper;

import lombok.AllArgsConstructor;
import lombok.Setter;
import lombok.extern.log4j.Log4j;

@Log4j
@Service
@AllArgsConstructor
public class TimeTableServiceImpl implements TimeTableService {

	@Setter(onMethod_ = @Autowired)
	private TimeTableMapper mapper;

	@Override
	public void register(TimeTableVO timeTable) {

		log.info("register......" + timeTable);

		mapper.insertSelectKey(timeTable);
	}

	@Override
	public TimeTableVO get(String professor) {

		log.info("get......" + professor);

		return mapper.select(professor);

	}

	@Override
	public boolean modify(TimeTableVO timeTable) {

		log.info("modify......" + timeTable);

		return mapper.modify(timeTable) == 1;
	}

	@Override
	public boolean remove(String professor) {

		log.info("remove...." + professor);

		return mapper.remove(professor) == 1;
	}

	 @Override
	 public List<TimeTableVO> getList() {
	
	 log.info("getList..........");
	
	 return mapper.getList();
	 }


}
