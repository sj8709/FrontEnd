package com.inhatc.mapper;

import java.util.List;


import com.inhatc.domain.StudentInfoVO;

public interface StudentInfoMapper {


	public List<StudentInfoVO> getList();
	
	public void insert(StudentInfoVO studentInfo);
	
	public StudentInfoVO select(String stu_id);
	
	public int modify(StudentInfoVO studentInfo);
	
	public int remove(String stu_id);

}
