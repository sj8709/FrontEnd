package com.inhatc.mapper;

import java.util.List;

import com.inhatc.domain.TimeTableVO;

public interface TimeTableMapper {


	public List<TimeTableVO> getList();
	
	public void insert(TimeTableVO timeTable);

	public Integer insertSelectKey(TimeTableVO timeTable);
	public TimeTableVO select(String professor);
	
	public int modify(TimeTableVO timeTable);
	
	public int remove(String professor);

}
