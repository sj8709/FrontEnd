package com.inhatc.service;

import static org.junit.Assert.assertNotNull;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import com.inhatc.domain.TimeTableVO;
//import com.inhatc.domain.Criteria;

import lombok.Setter;
import lombok.extern.log4j.Log4j;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration("file:src/main/webapp/WEB-INF/spring/root-context.xml")

@Log4j
public class TimeTableServiceTests {

	@Setter(onMethod_ = { @Autowired })
	private TimeTableService service;

	@Test
	public void testExist() {

		log.info(service);
		assertNotNull(service);
	}

	@Test
	public void testRegister() {

		TimeTableVO timeTable = new TimeTableVO();
		timeTable.setGrade(1L);
		timeTable.setTclass("A반");
		timeTable.setProfessor("A교수");
		timeTable.setDay_of_week("Mon");
		timeTable.setRoom("1-101");

		service.register(timeTable);

		log.info("새 일련번호: " + timeTable.getTno());
	}


	@Test
	public void testGet() {

		log.info(service.get("A교수"));
	}

	@Test
	public void testUpdate() {

		TimeTableVO timeTable = service.get("A교수");

		if (timeTable == null) {
			return;
		}

		timeTable.setRoom("강의실 수정");
		log.info("MODIFY RESULT: " + service.modify(timeTable));
	}
	@Test
	public void testDelete() {

		log.info("REMOVE RESULT: " + service.remove("A교수"));

	}

}
