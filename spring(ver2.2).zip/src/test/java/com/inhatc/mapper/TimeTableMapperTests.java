package com.inhatc.mapper;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.inhatc.domain.TimeTableVO;

import lombok.Setter;
import lombok.extern.log4j.Log4j;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration("file:src/main/webapp/WEB-INF/spring/root-context.xml")
//Java Config
//@ContextConfiguration(classes = {org.zerock.config.RootConfig.class} )
@Log4j
public class TimeTableMapperTests {
	
	@Setter(onMethod_ = @Autowired)
	private TimeTableMapper mapper;
	
	@Test
	public void testGetList() {
		mapper.getList().forEach(timeTable -> log.info(timeTable));
	}

	@Test
	public void testInsert() {
		
		TimeTableVO timeTable = new TimeTableVO();
		timeTable.setGrade(1L);
		timeTable.setTclass("A��");
		timeTable.setProfessor("A����");
		timeTable.setDay_of_week("Mon");
		timeTable.setRoom("1-101");
		
		mapper.insert(timeTable);
		
		log.info(timeTable);
	}
	
	@Test
	public void testInsertSelectKey() {

		TimeTableVO timeTable = new TimeTableVO();
		timeTable.setGrade(1L);
		timeTable.setTclass("A��");
		timeTable.setProfessor("B����");
		timeTable.setDay_of_week("Mon");
		timeTable.setRoom("1-101");
		
		mapper.insertSelectKey(timeTable);
		
		log.info(timeTable);
	}
	
	@Test
	public void testSelect() {
		
		TimeTableVO timeTable = mapper.select("A����");
		
		log.info(timeTable);
	}
	
	@Test
	public void testModify() {
		
		TimeTableVO timeTable = new TimeTableVO();
		
		timeTable.setTno(1L);
		timeTable.setGrade(2L);
		timeTable.setTclass("A��");
		timeTable.setProfessor("C����");
		timeTable.setDay_of_week("Wed");
		timeTable.setRoom("2-222");
		
		int count = mapper.modify(timeTable);
		log.info("MODIFY COUNT: " + count);
	}
	
	@Test
	public void testRemove() {
		log.info("REMOVE COUNT: " + mapper.remove("C����"));
	}

}
