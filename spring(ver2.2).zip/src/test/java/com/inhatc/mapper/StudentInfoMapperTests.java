package com.inhatc.mapper;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.inhatc.domain.StudentInfoVO;

import lombok.Setter;
import lombok.extern.log4j.Log4j;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration("file:src/main/webapp/WEB-INF/spring/root-context.xml")
//Java Config
//@ContextConfiguration(classes = {org.zerock.config.RootConfig.class} )
@Log4j
public class StudentInfoMapperTests {
	
	@Setter(onMethod_ = @Autowired)
	private StudentInfoMapper mapper;
	
	@Test
	public void testGetList() {
		mapper.getList().forEach(studentInfo -> log.info(studentInfo));
	}

	@Test
	public void testInsert() {
		
		StudentInfoVO studentInfo = new StudentInfoVO();
		studentInfo.setStu_id("2010001");
		studentInfo.setStu_name("ȫ�浿");
		studentInfo.setAddress("�츮��");
		studentInfo.setPhone("010-1111-2222");
		studentInfo.setEmail("asdasd@asda.asdad");
		
		mapper.insert(studentInfo);
		
		log.info(studentInfo);
	}
	/*
	@Test
	public void testSelect() {
		
		StudentInfoVO studentInfo = mapper.select("2010001");
		
		log.info(studentInfo);
	}
	
	@Test
	public void testRemove() {
		log.info("DELETE COUNT: " + mapper.remove("2010001"));
	}

	@Test
	public void testModify() {
		
		StudentInfoVO studentInfo = new StudentInfoVO();
		
		studentInfo.setStu_id("2010001");
		studentInfo.setStu_name("�ձ浿");
		studentInfo.setAddress("�ʳ���");
		studentInfo.setPhone("010-2222-1111");
		studentInfo.setEmail("hjkhjk@iukjh.hjkhj");
		
		int count = mapper.modify(studentInfo);
		log.info("UPDATE COUNT: " + count);
	}*/

}
